<?php
/**
 * Plugin Name: Groundworx Foundation
 * Description: Core block extensions and support modules for WordPress blocks including animations, overlay, scroll effects, and more.
 * Version: 1.0.2
 * Requires at least: 6.5
 * Tested up to: 6.9
 * Requires PHP: 8.2
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Author: Groundworx
 * Text Domain: groundworx-foundation
 * Author URI: https://groundworx.dev
 * Item ID: 1620
 * API URL: https://groundworx.dev/
 * Support URL: https://groundworx.dev/help/
 */
namespace GroundworxFoundation;

defined( 'ABSPATH' ) || exit;

define( 'GroundworxFoundation\PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GroundworxFoundation\PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'GroundworxFoundation\PLUGIN_FILE', plugin_basename( __FILE__ ) );

/**
 * Get plugin info from file header.
 *
 * @return array Plugin info with version, item_id, and api_url.
 */
function get_plugin_info() {
    static $info = null;
    if ( $info === null ) {
        $info = get_file_data( __FILE__, [
            'name'        => 'Plugin Name',
            'version'     => 'Version',
            'item_id'     => 'Item ID',
            'api_url'     => 'API URL',
            'docs_url'    => 'Docs URL',
            'support_url' => 'Support URL',
        ]);
    }
    return $info;
}

require_once PLUGIN_DIR . 'inc/utils.php';
require_once PLUGIN_DIR . 'inc/class-gravityforms-block-buttons.php';

class Plugin {
    /** @var string The plugin version number. */
    var $version;

    /**
     * Constructor
     *
     * Initializes the plugin version.
     */
    function __construct() {
        $this->version = get_plugin_info()['version'];
    }

    /**
     * Initialize plugin hooks and features.
     */
    function initialize() {

        // Plugin updates (no license required).
        add_action( 'plugins_loaded', array($this, 'plugin_updater'));

        // Support files.
        add_action( 'init', array( $this, 'include_support_assets' ), 5 );

        // Blocks.
        add_action( 'init', array( $this, 'load_blocks' ), 5 );

        add_action( 'enqueue_block_editor_assets', [ $this, 'supports_enqueue_editor_scripts'], 101 );
        add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_scripts'], 100 );
        add_action( 'enqueue_block_assets', [ $this, 'supports_enqueue_all_styles'], 101 );
        add_action( 'enqueue_block_assets', [ $this, 'supports_enqueue_scripts'], 101 );

        // Frontend styles (form styling).
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles'], 101 );

        // Admin settings.
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_menu', array( $this, 'register_shared_settings_page' ), 5 );
        add_filter( 'groundworx_settings_sections', array( $this, 'register_settings_section' ) );

        // REST API for settings.
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Admin settings page scripts.
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
    }

    /**
     * Register the shared Groundworx settings page if not already registered.
     */
    function register_shared_settings_page() {
        global $groundworx_settings_page_registered;

        // Only register once across all Groundworx plugins
        if ( ! empty( $groundworx_settings_page_registered ) ) {
            return;
        }

        add_submenu_page(
            'tools.php',
            'Groundworx',
            'Groundworx',
            'manage_options',
            'groundworx',
            [ __CLASS__, 'render_shared_settings_page' ]
        );

        $groundworx_settings_page_registered = true;
    }

    /**
     * Render the shared Groundworx settings page.
     * This is a static method so any plugin can call it.
     */
    public static function render_shared_settings_page() {
        // Get registered sections via filter
        $sections = apply_filters( 'groundworx_settings_sections', [] );

        // Sort by priority
        usort( $sections, function( $a, $b ) {
            return ( $a['priority'] ?? 50 ) - ( $b['priority'] ?? 50 );
        });

        // Determine active section
        $active_id = isset( $_GET['section'] ) ? sanitize_key( $_GET['section'] ) : '';
        if ( empty( $active_id ) && ! empty( $sections ) ) {
            $active_id = $sections[0]['id'];
        }
        ?>
        <style>
            .groundworx-settings-page {
                display: flex;
                gap: 0;
                max-width: 900px;
                background: #fff;
                border: 1px solid #c3c4c7;
                border-radius: 4px;
                margin-top: 20px;
            }
            /* Sidebar navigation */
            .groundworx-settings-nav {
                width: 200px;
                flex-shrink: 0;
                background: #f6f7f7;
                border-right: 1px solid #c3c4c7;
                padding: 0;
                margin: 0;
                list-style: none;
            }
            .groundworx-settings-nav li {
                margin: 0;
            }
            .groundworx-settings-nav a {
                display: block;
                padding: 12px 16px;
                text-decoration: none;
                color: #1d2327;
                border-bottom: 1px solid #c3c4c7;
                font-weight: 500;
            }
            .groundworx-settings-nav a:hover {
                background: #fff;
            }
            .groundworx-settings-nav a.active {
                background: #fff;
                border-left: 3px solid #2271b1;
                margin-left: -1px;
                margin-right: -1px;
                color: #2271b1;
            }
            .groundworx-settings-nav a .nav-description {
                display: block;
                font-size: 12px;
                font-weight: 400;
                color: #646970;
                margin-top: 2px;
            }
            /* Content area */
            
            /* Override license form styling within sections */
            .groundworx-settings-section .fct_licensing_wrap {
                margin: 0;
                border: none;
                max-width: none;
                background: transparent;
            }
           
            .groundworx-settings-section .fct_licensing_form {
                gap: 10px;
            }
            .groundworx-settings-section .fct_licensing_form input {
                max-width: 400px;
            }
            
            .groundworx-settings-section .gwx-settings-description {
                display: none;
            }

            .groundworx-settings-content { flex: 1; min-width: 0; }
            .groundworx-settings-section { display: none; padding: 24px; }
            .groundworx-settings-section.active { display: block; }
        </style>
        <div class="wrap">
            <h1>Groundworx</h1>
            <div class="groundworx-settings-page">
                <?php if ( ! empty( $sections ) ) : ?>
                <ul class="groundworx-settings-nav">
                    <?php foreach ( $sections as $section ) :
                        $is_active = $section['id'] === $active_id;
                        $url = admin_url( 'tools.php?page=groundworx&section=' . $section['id'] );
                    ?>
                    <li>
                        <a href="<?php echo esc_url( $url ); ?>"<?php echo $is_active ? ' class="active"' : ''; ?>>
                            <?php echo esc_html( $section['title'] ); ?>
                            <span class="nav-description"><?php echo esc_html( $section['description'] ); ?></span>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>

                <div class="groundworx-settings-content">
                    <?php
                    foreach ( $sections as $section ) {
                        $is_active = $section['id'] === $active_id;
                        $active_class = $is_active ? ' active' : '';
                        echo '<div class="groundworx-settings-section' . $active_class . '" id="' . esc_attr( $section['id'] ) . '">';
                        echo '<h2>' . esc_html( $section['title'] ) . '</h2>';
                        echo '<p class="description">' . esc_html( $section['description'] ) . '</p>';
                        if ( is_callable( $section['callback'] ) ) {
                            call_user_func( $section['callback'] );
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Register this plugin's settings section.
     *
     * @param array $sections Existing sections.
     * @return array Modified sections.
     */
    function register_settings_section( $sections ) {
        $sections[] = [
            'id'          => 'groundworx-foundation-section',
            'title'       => __( 'Foundation', 'groundworx-foundation' ),
            'description' => __( 'Core block extensions and support modules.', 'groundworx-foundation' ),
            'priority'    => 10,
            'callback'    => function() {
                echo '<div id="groundworx-foundation-settings"></div>';
            },
        ];
        return $sections;
    }

    /**
     * Get the display order for supports.
     *
     * @return array Ordered list of support slugs.
     */
    protected function get_support_order() {
        return [
            // Core block extensions
            'core-columns-extend',
            'core-column-extend',
            'core-group-sticky-full-height',
            'core-list-extend',
            'core-headings',
            'responsive-text-align',
            // Global theme styling
            'form-base',
            'gravityforms-block',
            'has-background-padding',
            'responsive-content-size',
            'min-height-alteration',
        ];
    }

    /**
     * Get metadata for all available supports from block.json files.
     *
     * @return array Support metadata with labels, descriptions, and dependencies.
     */
    protected function get_support_metadata() {
        static $metadata = null;

        if ( $metadata !== null ) {
            return $metadata;
        }

        // First, collect all metadata from block.json files
        $unordered = [];
        $support_dirs = glob( PLUGIN_DIR . 'build/supports/*', GLOB_ONLYDIR );

        foreach ( $support_dirs as $dir ) {
            $slug = basename( $dir );
            $block_json_path = $dir . '/block.json';

            if ( file_exists( $block_json_path ) ) {
                $block_json = json_decode( file_get_contents( $block_json_path ), true );

                if ( $block_json && isset( $block_json['title'] ) ) {
                    $unordered[ $slug ] = [
                        'label'        => __( $block_json['title'], 'groundworx-foundation' ),
                        'description'  => isset( $block_json['description'] ) ? __( $block_json['description'], 'groundworx-foundation' ) : '',
                        'dependencies' => isset( $block_json['dependencies'] ) ? $block_json['dependencies'] : [],
                        'blocks'       => isset( $block_json['blocks'] ) ? $block_json['blocks'] : [],
                        'theme'        => isset( $block_json['theme'] ) ? $block_json['theme'] : [],
                    ];
                }
            }
        }

        // Now order the metadata according to display order
        $metadata = [];
        foreach ( $this->get_support_order() as $slug ) {
            if ( isset( $unordered[ $slug ] ) ) {
                $metadata[ $slug ] = $unordered[ $slug ];
                unset( $unordered[ $slug ] );
            }
        }

        // Append any remaining supports not in the order list
        foreach ( $unordered as $slug => $data ) {
            $metadata[ $slug ] = $data;
        }

        return $metadata;
    }

    /**
     * Get enabled supports from settings.
     *
     * @return array Array of support slugs that are enabled.
     */
    protected function get_enabled_supports() {
        $defaults = [];
        foreach ( array_keys( $this->get_support_metadata() ) as $slug ) {
            $defaults[ $slug ] = true;
        }
        return get_option( 'groundworx_foundation_supports', $defaults );
    }


    /**
     * Check if a specific support is enabled.
     * Also checks if all required dependencies are enabled.
     *
     * @param string $support_slug The support slug to check.
     * @return bool True if enabled and all dependencies are met, false otherwise.
     */
    public function is_support_enabled( $support_slug ) {
        $enabled = $this->get_enabled_supports();
        $metadata = $this->get_support_metadata();

        // Check if this support itself is enabled
        $is_enabled = isset( $enabled[ $support_slug ] ) ? (bool) $enabled[ $support_slug ] : true;

        if ( ! $is_enabled ) {
            return false;
        }

        // Check if all dependencies are enabled
        if ( ! empty( $metadata[ $support_slug ]['dependencies'] ) ) {
            foreach ( $metadata[ $support_slug ]['dependencies'] as $required_slug ) {
                $required_enabled = isset( $enabled[ $required_slug ] ) ? (bool) $enabled[ $required_slug ] : true;
                if ( ! $required_enabled ) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Register plugin settings.
     */
    function register_settings() {
        register_setting( 'groundworx_foundation_settings', 'groundworx_foundation_supports', [
            'type'              => 'array',
            'default'           => [],
            'sanitize_callback' => array( $this, 'sanitize_supports_setting' ),
        ]);

        add_settings_section(
            'groundworx_foundation_supports',
            __( 'Supports', 'groundworx-foundation' ),
            array( $this, 'render_supports_section_description' ),
            'groundworx-foundation'
        );

        foreach ( $this->get_support_metadata() as $slug => $meta ) {
            add_settings_field(
                'groundworx_foundation_support_' . $slug,
                $meta['label'],
                array( $this, 'render_support_toggle' ),
                'groundworx-foundation',
                'groundworx_foundation_supports',
                [
                    'slug'        => $slug,
                    'label'       => $meta['label'],
                    'description' => $meta['description'],
                ]
            );
        }
    }

    /**
     * Sanitize supports setting.
     *
     * @param array $input The input array.
     * @return array Sanitized array.
     */
    function sanitize_supports_setting( $input ) {
        $sanitized = [];
        $valid_supports = array_keys( $this->get_support_metadata() );

        foreach ( $valid_supports as $slug ) {
            $sanitized[ $slug ] = isset( $input[ $slug ] ) ? (bool) $input[ $slug ] : false;
        }

        return $sanitized;
    }

    /**
     * Render the supports section description.
     */
    function render_supports_section_description() {
        echo '<p>' . esc_html__( 'Enable or disable individual block support features.', 'groundworx-foundation' ) . '</p>';
    }

    /**
     * Render a support toggle field.
     *
     * @param array $args Field arguments.
     */
    function render_support_toggle( $args ) {
        $slug = $args['slug'];
        $enabled = $this->is_support_enabled( $slug );
        ?>
        <label>
            <input type="checkbox"
                   name="groundworx_foundation_supports[<?php echo esc_attr( $slug ); ?>]"
                   value="1"
                   <?php checked( $enabled ); ?> />
            <?php echo esc_html( $args['description'] ); ?>
        </label>
        <?php
    }

    /**
     * Register REST API routes for settings.
     */
    function register_rest_routes() {
        register_rest_route( 'groundworx-foundation/v1', '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => array( $this, 'rest_get_settings' ),
                'permission_callback' => function() {
                    return current_user_can( 'manage_options' );
                },
            ],
            [
                'methods'             => 'POST',
                'callback'            => array( $this, 'rest_save_settings' ),
                'permission_callback' => function() {
                    return current_user_can( 'manage_options' );
                },
            ],
        ]);
    }

    /**
     * Get theme color palette for settings UI.
     *
     * @return array Color palette with name, slug, and color.
     */
    protected function get_theme_colors() {
        $colors = [];

        if ( function_exists( 'wp_get_global_settings' ) ) {
            $settings = wp_get_global_settings( [ 'color', 'palette' ] );
            if ( ! empty( $settings['theme'] ) ) {
                $colors = array_merge( $colors, $settings['theme'] );
            }
            if ( ! empty( $settings['custom'] ) ) {
                $colors = array_merge( $colors, $settings['custom'] );
            }
        }

        return $colors;
    }

    /**
     * Get available spacing units from theme settings.
     *
     * @return array Spacing units.
     */
    protected function get_spacing_units() {
        $units = [ 'px', 'em', 'rem', '%', 'vw', 'vh' ];

        if ( function_exists( 'wp_get_global_settings' ) ) {
            $settings = wp_get_global_settings( [ 'spacing', 'units' ] );
            if ( ! empty( $settings ) && is_array( $settings ) ) {
                $units = $settings;
            }
        }

        return $units;
    }

    /**
     * REST API callback to get settings.
     *
     * @return \WP_REST_Response
     */
    function rest_get_settings() {
        $response = [
            'supports'     => $this->get_enabled_supports(),
            'metadata'     => $this->get_support_metadata(),
            'themeColors'  => $this->get_theme_colors(),
            'spacingUnits' => $this->get_spacing_units(),
        ];

        // Add form defaults if the support is loaded
        if ( function_exists( 'GroundworxFoundation\Supports\FormBase\get_rest_data' ) ) {
            $response = array_merge( $response, \GroundworxFoundation\Supports\FormBase\get_rest_data() );
        }

        return rest_ensure_response( $response );
    }

    /**
     * REST API callback to save settings.
     *
     * @param \WP_REST_Request $request The request object.
     * @return \WP_REST_Response
     */
    function rest_save_settings( $request ) {
        $params = $request->get_json_params();

        if ( isset( $params['supports'] ) && is_array( $params['supports'] ) ) {
            $sanitized = $this->sanitize_supports_setting( $params['supports'] );
            update_option( 'groundworx_foundation_supports', $sanitized );
        }

        if ( isset( $params['formDefaults'] ) && is_array( $params['formDefaults'] ) ) {
            if ( function_exists( 'GroundworxFoundation\Supports\FormBase\save_form_defaults' ) ) {
                \GroundworxFoundation\Supports\FormBase\save_form_defaults( $params['formDefaults'] );
            }
        }

        $response = [
            'success'  => true,
            'supports' => $this->get_enabled_supports(),
        ];

        // Add form defaults if the support is loaded
        if ( function_exists( 'GroundworxFoundation\Supports\FormBase\get_rest_data' ) ) {
            $response = array_merge( $response, \GroundworxFoundation\Supports\FormBase\get_rest_data() );
        }

        return rest_ensure_response( $response );
    }

    /**
     * Enqueue admin scripts for settings page.
     *
     * @param string $hook The current admin page hook.
     */
    function enqueue_admin_scripts( $hook ) {
        // Only load on the shared Groundworx settings page
        if ( 'tools_page_groundworx' !== $hook ) {
            return;
        }

        $asset_file = PLUGIN_DIR . 'build/admin.asset.php';
        if ( ! file_exists( $asset_file ) ) {
            return;
        }

        $asset = include $asset_file;

        wp_enqueue_script(
            'groundworx-foundation-admin',
            plugins_url( 'build/admin.js', __FILE__ ),
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_enqueue_style(
            'groundworx-foundation-admin',
            plugins_url( 'build/admin.css', __FILE__ ),
            [ 'wp-components' ],
            $asset['version']
        );
    }

    /**
     * Initialize the plugin updater.
     */
    function plugin_updater() {
        require_once PLUGIN_DIR . 'updater/PluginUpdater.php';

        if (class_exists('\GroundworxFoundation\PluginUpdater')) {
            $info = get_plugin_info();
            new \GroundworxFoundation\PluginUpdater([
                'slug'                 => 'groundworx-foundation',
                'basename'             => plugin_basename( PLUGIN_FILE ),
                'version'              => $info['version'],
                'api_url'              => $info['api_url'],
                'item_id'              => (int) $info['item_id'],
            ]);
        }
    }

    /**
     * Define a constant if it doesn't already exist.
     *
     * @param string $name  Constant name.
     * @param mixed  $value Constant value.
     */
    function define( $name, $value = true ) {
        if( !defined($name) ) {
            define( $name, $value );
        }
    }

    /**
     * Get all support directories.
     *
     * @return array Array of support directory paths.
     */
    protected function get_supports() {
        return glob(PLUGIN_DIR . 'build/supports/*', GLOB_ONLYDIR);
    }

    /**
     * Include support asset PHP files.
     */
    public function include_support_assets() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            if (file_exists("$dir/support.php")) {
                include "$dir/support.php";
            }
        }
    }

    /**
     * Enqueue support scripts for frontend and editor.
     */
    public function supports_enqueue_scripts() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            $src = str_replace(ABSPATH, '', $dir);

            if (file_exists("$dir/index.asset.php")) {
                $asset = include("$dir/index.asset.php");
                wp_enqueue_script("support-$name-script", "/$src/index.js", $asset['dependencies'], $asset['version'], true);
            }
        }
    }

    /**
     * Enqueue support scripts for block editor only.
     */
    public function supports_enqueue_editor_scripts() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            $src = str_replace(ABSPATH, '', $dir);

            if (file_exists("$dir/editor.asset.php")) {
                $asset = include("$dir/editor.asset.php");
                wp_enqueue_script("support-$name-editor-script", "/$src/editor.js", $asset['dependencies'], $asset['version'], true);
            }
            if (file_exists("$dir/editor.css")) {
                wp_enqueue_style("support-$name-editor-style", "/$src/editor.css", [], filemtime("$dir/editor.css"));
            }
        }
    }

    /**
     * Enqueue support styles for frontend and editor.
     */
    public function supports_enqueue_all_styles() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            $src = str_replace(ABSPATH, '', $dir);

            if (file_exists("$dir/index.css")) {
                wp_enqueue_style("support-$name-style", "/$src/index.css", [], filemtime("$dir/index.css"));
            }
        }
    }

    /**
     * Load all block registration files.
     */
    function load_blocks() {
        $blocks = glob( PLUGIN_DIR . 'build/blocks/**/block.php' );
        if (!empty($blocks)) {
            foreach (array_unique($blocks) as $block) {
                if (is_file($block)) require_once $block;
            }
        }
    }

    /**
     * Enqueue frontend scripts.
     */
    public function enqueue_scripts() {
        $asset_file_path = PLUGIN_DIR . 'build/main.asset.php';
        $script_file_path = PLUGIN_DIR . 'build/main.js';

        if ( !file_exists( $asset_file_path ) ) {
            return;
        }

        if ( !file_exists( $script_file_path ) ) {
            return;
        }

        $asset_file = include( $asset_file_path );

        $scripts = [
            [
                'label' => "groundworx-foundation-scripts",
                'src' => plugins_url('/build/main.js', __FILE__ ),
                'dependencies' => $asset_file['dependencies'],
                'version' => $asset_file['version'],
                'in_footer' => true
            ],
        ];

        foreach ($scripts as $script) {
            wp_register_script(
                $script['label'],
                $script['src'],
                $script['dependencies'],
                $script['version'],
                $script['in_footer']
            );

            wp_enqueue_script($script['label']);
        }
    }

    /**
     * Enqueue editor scripts.
     */
    public function enqueue_editor_scripts() {
        $asset_file_path = PLUGIN_DIR . 'build/editor.asset.php';
        $script_file_path = PLUGIN_DIR . 'build/editor.js';

        if ( !file_exists( $asset_file_path ) ) {
            return;
        }

        if ( !file_exists( $script_file_path ) ) {
            return;
        }

        $asset_file = include( $asset_file_path );

        $scripts = [
            [
                'label' => "groundworx-foundation-editor-scripts",
                'src' => plugins_url('/build/editor.js', __FILE__ ),
                'dependencies' => $asset_file['dependencies'],
                'version' => $asset_file['version'],
                'in_footer' => true
            ],
        ];

        foreach ($scripts as $script) {
            wp_register_script(
                $script['label'],
                $script['src'],
                $script['dependencies'],
                $script['version'],
                $script['in_footer']
            );

            wp_enqueue_script($script['label']);
        }
    }

    /**
     * Enqueue frontend styles.
     */
    public function enqueue_styles() {
        $asset_file_path = PLUGIN_DIR . 'build/main.asset.php';
        $style_file_path = PLUGIN_DIR . 'build/main.css';

        if ( !file_exists( $asset_file_path ) ) {
            return;
        }

        if ( !file_exists( $style_file_path ) ) {
            return;
        }

        $asset_file = include( $asset_file_path );

        $styles = [
            [
                'label' => "groundworx-foundation-css-main",
                'src' => plugins_url('/build/main.css', __FILE__ ),
                'dependencies' => $asset_file['dependencies'],
                'version' => $asset_file['version'],
            ]
        ];

        foreach ($styles as $style) {
            wp_register_style(
                $style['label'],
                $style['src'],
                $style['dependencies'],
                $style['version'],
                false
            );

            wp_enqueue_style($style['label']);
        }

    }

}

/**
 * Main instance of Groundworx Foundation.
 *
 * Returns the main instance of the plugin to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return Plugin
 */
function groundworx_foundation() {
    global $groundworx_foundation;
    if (!isset($groundworx_foundation)) {
        $groundworx_foundation = new Plugin();
        $groundworx_foundation->initialize();
    }
    return $groundworx_foundation;
}
// Deactivate groundworx-gravityforms plugin on activation (functionality now included)
register_activation_hook( __FILE__, function() {
    $plugin = 'groundworx-gravityforms/groundworx-gravityforms.php';
    if ( is_plugin_active( $plugin ) ) {
        deactivate_plugins( $plugin );
    }
});

// Initialize the plugin
groundworx_foundation();
