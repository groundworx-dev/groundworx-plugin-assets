<?php
/**
 * Plugin Name: Groundworx Foundation
 * Description: Responsive layout blocks, core block extensions, rich text formats, and global form styling for WordPress.
 * Version: 1.1.0
 * Requires at least: 6.5
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Author: Groundworx
 * Text Domain: groundworx-foundation
 * Author URI: https://groundworx.dev
 * Item ID: 1620
 * API URL: https://groundworx.dev/
 * Support URL: https://groundworx.dev/help/
 */
namespace GroundworxFoundation;

defined( 'ABSPATH' ) || exit;

define( 'GroundworxFoundation\PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GroundworxFoundation\PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'GroundworxFoundation\PLUGIN_FILE', plugin_basename( __FILE__ ) );

/**
 * Get plugin info from file header.
 *
 * @return array Plugin info with version, item_id, and api_url.
 */
function get_plugin_info() {
    static $info = null;
    if ( $info === null ) {
        $info = get_file_data( __FILE__, [
            'name'        => 'Plugin Name',
            'version'     => 'Version',
            'item_id'     => 'Item ID',
            'api_url'     => 'API URL',
            'docs_url'    => 'Docs URL',
            'support_url' => 'Support URL',
        ]);
    }
    return $info;
}

require_once PLUGIN_DIR . 'inc/utils.php';
require_once PLUGIN_DIR . 'inc/grid-helpers.php';
require_once PLUGIN_DIR . 'inc/class-gravityforms-block-buttons.php';
require_once PLUGIN_DIR . 'inc/class-post-labels.php';

class Plugin {
    /** @var string The plugin version number. */
    var $version;

    /**
     * Constructor
     *
     * Initializes the plugin version.
     */
    function __construct() {
        $this->version = get_plugin_info()['version'];
    }

    /**
     * Initialize plugin hooks and features.
     */
    function initialize() {

        // Plugin updates (no license required).
        add_action( 'plugins_loaded', array($this, 'plugin_updater'));

        // Support files.
        add_action( 'init', array( $this, 'include_support_assets' ), 5 );

        // Blocks.
        add_action( 'init', array( $this, 'load_blocks' ), 5 );

        add_action( 'init', array( $this, 'register_assets' ), 5 );
        add_action( 'enqueue_block_assets', array( $this, 'enqueue_support_styles' ), 101 );
        add_action( 'init', function() {
            if ( $this->is_support_enabled( 'form-base' ) ) {
                add_action( 'enqueue_block_assets', 'GroundworxFoundation\Supports\FormBase\output_css_variables', 102 );
            }
        }, 6 );
        add_action( 'enqueue_block_editor_assets', [ $this, 'supports_enqueue_editor_scripts'], 101 );
        add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 100 );

        // Post Labels (rename Posts post type).
        new PostLabels();

        // Admin settings.
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 5 );

        // REST API for settings.
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Admin settings page scripts.
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

        // Plugin action links.
        add_filter( 'plugin_action_links_' . PLUGIN_FILE, array( $this, 'add_plugin_action_links' ) );
    }

    /**
     * Add settings link to plugin action links.
     */
    function add_plugin_action_links( $links ) {
        array_unshift( $links, '<a href="' . admin_url( 'admin.php?page=gwx-foundation' ) . '">' . __( 'Settings', 'groundworx-foundation' ) . '</a>' );
        return $links;
    }

    /**
     * Register the top-level Groundworx menu and Foundation submenu.
     */
    function register_admin_menu() {
        global $groundworx_menu_registered;

        // Register the top-level menu once across all Groundworx plugins.
        if ( empty( $groundworx_menu_registered ) ) {
            add_menu_page(
                __( 'Groundworx', 'groundworx-foundation' ),
                __( 'Groundworx', 'groundworx-foundation' ),
                'manage_options',
                'gwx-settings',
                '__return_null',
                'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-5.707 -5 70 90"><g><path d="M40.271,32.641c.548,1.594.85,3.301.85,5.078,0,8.634-7.024,15.658-15.658,15.658s-15.658-7.024-15.658-15.658c0-8.531,6.859-15.485,15.351-15.65l3.106-9.657c-.92-.101-1.853-.156-2.799-.156-14.063,0-25.463,11.4-25.463,25.463s11.4,25.463,25.463,25.463,25.463-11.4,25.463-25.463c0-3.346-.652-6.539-1.825-9.466l-8.83,4.389Z" fill="currentColor"/><path d="M29.649,80c-3.745,0-7.497-.688-11.1-2.067l3.507-9.157c5.287,2.025,11.046,1.87,16.216-.437,5.171-2.306,9.133-6.488,11.158-11.775l9.157,3.507c-2.962,7.733-8.758,13.849-16.32,17.223-4.039,1.802-8.325,2.706-12.619,2.706Z" fill="currentColor"/><polygon points="38.968 0 45.082 12.381 58.238 16.575 28.957 31.127 38.968 0" fill="currentColor"/></g></svg>' ),
                81 // After Settings (80).
            );
            $groundworx_menu_registered = true;
        }

        // Register the shared Licenses page once across all Groundworx plugins.
        global $groundworx_licenses_registered;
        if ( empty( $groundworx_licenses_registered ) ) {
            add_submenu_page(
                'gwx-settings',
                __( 'Licenses', 'groundworx-foundation' ),
                __( 'Licenses', 'groundworx-foundation' ),
                'manage_options',
                'gwx-licenses',
                [ __CLASS__, 'render_licenses_page' ]
            );
            $groundworx_licenses_registered = true;
        }

        add_submenu_page(
            'gwx-settings',
            __( 'Foundation', 'groundworx-foundation' ),
            __( 'Foundation', 'groundworx-foundation' ),
            'manage_options',
            'gwx-foundation',
            [ $this, 'render_settings_page' ]
        );

        // Remove the auto-generated duplicate submenu item.
        remove_submenu_page( 'gwx-settings', 'gwx-settings' );
    }

    /**
     * Render the Foundation settings page.
     */
    function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Foundation', 'groundworx-foundation' ); ?></h1>
            <div id="groundworx-foundation-settings"></div>
        </div>
        <?php
    }

    /**
     * Render the shared Licenses page.
     * Each plugin hooks into 'groundworx_render_licenses' to render its own card.
     */
    static function render_licenses_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Licenses', 'groundworx-foundation' ); ?></h1>
            <?php do_action( 'groundworx_render_licenses' ); ?>
        </div>
        <?php
    }

    /**
     * Get the display order for supports.
     *
     * @return array Ordered list of support slugs.
     */
    protected function get_support_order() {
        return [
            // Core block extensions
            'core-columns-extend',
            'core-column-extend',
            'core-group-sticky-full-height',
            'core-list-extend',
            'core-headings',
            'responsive-text-align',
            // Global theme styling
            'form-base',
            'gravityforms-block',
            'has-background-padding',
            'min-height-alteration',
        ];
    }

    /**
     * Get metadata for all available supports from block.json files.
     *
     * @return array Support metadata with labels, descriptions, and dependencies.
     */
    protected function get_support_metadata() {
        static $metadata = null;

        if ( $metadata !== null ) {
            return $metadata;
        }

        // First, collect all metadata from block.json files
        $unordered = [];
        $support_dirs = glob( PLUGIN_DIR . 'build/supports/*', GLOB_ONLYDIR );

        foreach ( $support_dirs as $dir ) {
            $slug = basename( $dir );
            $block_json_path = $dir . '/block.json';

            if ( file_exists( $block_json_path ) ) {
                $block_json = json_decode( file_get_contents( $block_json_path ), true );

                if ( $block_json && isset( $block_json['title'] ) ) {
                    $unordered[ $slug ] = [
                        'label'        => __( $block_json['title'], 'groundworx-foundation' ),
                        'description'  => isset( $block_json['description'] ) ? __( $block_json['description'], 'groundworx-foundation' ) : '',
                        'dependencies' => isset( $block_json['dependencies'] ) ? $block_json['dependencies'] : [],
                        'blocks'       => isset( $block_json['blocks'] ) ? $block_json['blocks'] : [],
                        'theme'        => isset( $block_json['theme'] ) ? $block_json['theme'] : [],
                    ];
                }
            }
        }

        // Now order the metadata according to display order
        $metadata = [];
        foreach ( $this->get_support_order() as $slug ) {
            if ( isset( $unordered[ $slug ] ) ) {
                $metadata[ $slug ] = $unordered[ $slug ];
                unset( $unordered[ $slug ] );
            }
        }

        // Append any remaining supports not in the order list
        foreach ( $unordered as $slug => $data ) {
            $metadata[ $slug ] = $data;
        }

        return $metadata;
    }

    /**
     * Get enabled supports from settings.
     *
     * @return array Array of support slugs that are enabled.
     */
    protected function get_enabled_supports() {
        $defaults = [];
        foreach ( array_keys( $this->get_support_metadata() ) as $slug ) {
            $defaults[ $slug ] = true;
        }
        return get_option( 'groundworx_foundation_supports', $defaults );
    }


    /**
     * Check if a specific support is enabled.
     * Also checks if all required dependencies are enabled.
     *
     * @param string $support_slug The support slug to check.
     * @return bool True if enabled and all dependencies are met, false otherwise.
     */
    public function is_support_enabled( $support_slug ) {
        $enabled = $this->get_enabled_supports();
        $metadata = $this->get_support_metadata();

        // Check if this support itself is enabled
        $is_enabled = isset( $enabled[ $support_slug ] ) ? (bool) $enabled[ $support_slug ] : true;

        if ( ! $is_enabled ) {
            return false;
        }

        // Check if all dependencies are enabled
        if ( ! empty( $metadata[ $support_slug ]['dependencies'] ) ) {
            foreach ( $metadata[ $support_slug ]['dependencies'] as $required_slug ) {
                $required_enabled = isset( $enabled[ $required_slug ] ) ? (bool) $enabled[ $required_slug ] : true;
                if ( ! $required_enabled ) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Register plugin settings.
     */
    function register_settings() {
        register_setting( 'groundworx_foundation_settings', 'groundworx_foundation_supports', [
            'type'              => 'array',
            'default'           => [],
            'sanitize_callback' => array( $this, 'sanitize_supports_setting' ),
        ]);

        add_settings_section(
            'groundworx_foundation_supports',
            __( 'Supports', 'groundworx-foundation' ),
            array( $this, 'render_supports_section_description' ),
            'groundworx-foundation'
        );

        foreach ( $this->get_support_metadata() as $slug => $meta ) {
            add_settings_field(
                'groundworx_foundation_support_' . $slug,
                $meta['label'],
                array( $this, 'render_support_toggle' ),
                'groundworx-foundation',
                'groundworx_foundation_supports',
                [
                    'slug'        => $slug,
                    'label'       => $meta['label'],
                    'description' => $meta['description'],
                ]
            );
        }
    }

    /**
     * Sanitize supports setting.
     *
     * @param array $input The input array.
     * @return array Sanitized array.
     */
    function sanitize_supports_setting( $input ) {
        $sanitized = [];
        $valid_supports = array_keys( $this->get_support_metadata() );

        foreach ( $valid_supports as $slug ) {
            $sanitized[ $slug ] = isset( $input[ $slug ] ) ? (bool) $input[ $slug ] : false;
        }

        return $sanitized;
    }

    /**
     * Render the supports section description.
     */
    function render_supports_section_description() {
        echo '<p>' . esc_html__( 'Enable or disable individual block support features.', 'groundworx-foundation' ) . '</p>';
    }

    /**
     * Render a support toggle field.
     *
     * @param array $args Field arguments.
     */
    function render_support_toggle( $args ) {
        $slug = $args['slug'];
        $enabled = $this->is_support_enabled( $slug );
        ?>
        <label>
            <input type="checkbox"
                   name="groundworx_foundation_supports[<?php echo esc_attr( $slug ); ?>]"
                   value="1"
                   <?php checked( $enabled ); ?> />
            <?php echo esc_html( $args['description'] ); ?>
        </label>
        <?php
    }

    /**
     * Register REST API routes for settings.
     */
    function register_rest_routes() {
        register_rest_route( 'groundworx-foundation/v1', '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => array( $this, 'rest_get_settings' ),
                'permission_callback' => function() {
                    return current_user_can( 'manage_options' );
                },
            ],
            [
                'methods'             => 'POST',
                'callback'            => array( $this, 'rest_save_settings' ),
                'permission_callback' => function() {
                    return current_user_can( 'manage_options' );
                },
            ],
        ]);
    }

    /**
     * Get theme color palette for settings UI.
     *
     * @return array Color palette with name, slug, and color.
     */
    protected function get_theme_colors() {
        $colors = [];

        if ( function_exists( 'wp_get_global_settings' ) ) {
            $settings = wp_get_global_settings( [ 'color', 'palette' ] );
            if ( ! empty( $settings['theme'] ) ) {
                $colors = array_merge( $colors, $settings['theme'] );
            }
            if ( ! empty( $settings['custom'] ) ) {
                $colors = array_merge( $colors, $settings['custom'] );
            }
        }

        return $colors;
    }

    /**
     * Get available spacing units from theme settings.
     *
     * @return array Spacing units.
     */
    protected function get_spacing_units() {
        $units = [ 'px', 'em', 'rem', '%', 'vw', 'vh' ];

        if ( function_exists( 'wp_get_global_settings' ) ) {
            $settings = wp_get_global_settings( [ 'spacing', 'units' ] );
            if ( ! empty( $settings ) && is_array( $settings ) ) {
                $units = $settings;
            }
        }

        return $units;
    }

    /**
     * REST API callback to get settings.
     *
     * @return \WP_REST_Response
     */
    function rest_get_settings() {
        $response = [
            'supports'     => $this->get_enabled_supports(),
            'metadata'     => $this->get_support_metadata(),
            'themeColors'  => $this->get_theme_colors(),
            'spacingUnits' => $this->get_spacing_units(),
        ];

        // Add form defaults if the support is loaded
        if ( function_exists( 'GroundworxFoundation\Supports\FormBase\get_rest_data' ) ) {
            $response = array_merge( $response, \GroundworxFoundation\Supports\FormBase\get_rest_data() );
        }

        // Post Labels settings.
        $response['postLabels'] = PostLabels::get_settings();
        $response['postLabelsPages'] = PostLabels::get_pages_data();

        return rest_ensure_response( $response );
    }

    /**
     * REST API callback to save settings.
     *
     * @param \WP_REST_Request $request The request object.
     * @return \WP_REST_Response
     */
    function rest_save_settings( $request ) {
        $params = $request->get_json_params();

        if ( isset( $params['supports'] ) && is_array( $params['supports'] ) ) {
            $sanitized = $this->sanitize_supports_setting( $params['supports'] );
            update_option( 'groundworx_foundation_supports', $sanitized );
        }

        if ( isset( $params['formDefaults'] ) && is_array( $params['formDefaults'] ) ) {
            if ( function_exists( 'GroundworxFoundation\Supports\FormBase\save_form_defaults' ) ) {
                \GroundworxFoundation\Supports\FormBase\save_form_defaults( $params['formDefaults'] );
            }
        }

        // Post Labels settings.
        if ( isset( $params['postLabels'] ) && is_array( $params['postLabels'] ) ) {
            PostLabels::save_settings( $params['postLabels'] );
        }

        // Page for Posts setting.
        if ( isset( $params['pageForPosts'] ) ) {
            PostLabels::save_page_for_posts( $params['pageForPosts'] );
        }

        $response = [
            'success'  => true,
            'supports' => $this->get_enabled_supports(),
        ];

        // Add form defaults if the support is loaded
        if ( function_exists( 'GroundworxFoundation\Supports\FormBase\get_rest_data' ) ) {
            $response = array_merge( $response, \GroundworxFoundation\Supports\FormBase\get_rest_data() );
        }

        // Post Labels settings.
        $response['postLabels'] = PostLabels::get_settings();
        $response['postLabelsPages'] = PostLabels::get_pages_data();

        return rest_ensure_response( $response );
    }

    /**
     * Enqueue admin scripts for settings page.
     *
     * @param string $hook The current admin page hook.
     */
    function enqueue_admin_scripts( $hook ) {
        // Only load on the Foundation settings page.
        if ( 'groundworx_page_gwx-foundation' !== $hook ) {
            return;
        }

        $asset_file = PLUGIN_DIR . 'build/admin.asset.php';
        if ( ! file_exists( $asset_file ) ) {
            return;
        }

        $asset = include $asset_file;

        wp_enqueue_script(
            'groundworx-foundation-admin',
            plugins_url( 'build/admin.js', __FILE__ ),
            $asset['dependencies'],
            $asset['version'],
            true
        );

        wp_enqueue_style(
            'groundworx-foundation-admin',
            plugins_url( 'build/admin.css', __FILE__ ),
            [ 'wp-components' ],
            $asset['version']
        );
    }

    /**
     * Initialize the plugin updater.
     */
    function plugin_updater() {
        require_once PLUGIN_DIR . 'updater/PluginUpdater.php';

        if (class_exists('\GroundworxFoundation\PluginUpdater')) {
            $info = get_plugin_info();
            new \GroundworxFoundation\PluginUpdater([
                'slug'       => 'groundworx-foundation',
                'basename'   => plugin_basename( PLUGIN_FILE ),
                'version'    => $info['version'],
                'update_url' => 'https://assets.groundworx.dev/groundworx-foundation/groundworx-foundation.json',
            ]);
        }
    }

    /**
     * Define a constant if it doesn't already exist.
     *
     * @param string $name  Constant name.
     * @param mixed  $value Constant value.
     */
    function define( $name, $value = true ) {
        if( !defined($name) ) {
            define( $name, $value );
        }
    }

    /**
     * Get all support directories.
     *
     * @return array Array of support directory paths.
     */
    protected function get_supports() {
        return glob(PLUGIN_DIR . 'build/supports/*', GLOB_ONLYDIR);
    }

    /**
     * Include support asset PHP files.
     */
    public function include_support_assets() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            if (file_exists("$dir/support.php")) {
                include "$dir/support.php";
            }
        }
    }

    /**
     * Enqueue consolidated support styles on the frontend.
     */
    public function enqueue_support_styles() {
        wp_enqueue_style( 'groundworx-foundation-support' );
    }

    /**
     * Enqueue support scripts for block editor only.
     */
    public function supports_enqueue_editor_scripts() {
        foreach ($this->get_supports() as $dir) {
            $name = basename($dir);
            if ( ! $this->is_support_enabled( $name ) ) {
                continue;
            }
            $src = str_replace(ABSPATH, '', $dir);

            if (file_exists("$dir/editor.asset.php")) {
                $asset = include("$dir/editor.asset.php");
                wp_enqueue_script("support-$name-editor-script", "/$src/editor.js", $asset['dependencies'], $asset['version'], true);
            }
            if (file_exists("$dir/editor.css")) {
                wp_enqueue_style("support-$name-editor-style", "/$src/editor.css", [], filemtime("$dir/editor.css"));
            }
        }
    }

    /**
     * Load all block registration files.
     */
    function load_blocks() {
        $blocks = glob( PLUGIN_DIR . 'build/blocks/**/block.php' );
        if (!empty($blocks)) {
            foreach (array_unique($blocks) as $block) {
                if (is_file($block)) require_once $block;
            }
        }
    }

    /**
     * Register shared assets — styles.
     */
    function register_assets() {
        // Frontend styles
        $style_asset = PLUGIN_DIR . 'build/main.asset.php';
        $style       = file_exists( $style_asset ) ? include( $style_asset ) : [ 'version' => false ];
        wp_register_style(
            'groundworx-foundation-style',
            plugins_url( 'build/style-main.css', __FILE__ ),
            [],
            $style['version']
        );

        // Support styles (registered early so wp_add_inline_style can attach)
        $support_asset = PLUGIN_DIR . 'build/support.asset.php';
        $support       = file_exists( $support_asset ) ? include( $support_asset ) : [ 'version' => false ];
        wp_register_style(
            'groundworx-foundation-support',
            plugins_url( 'build/support.css', __FILE__ ),
            [],
            $support['version']
        );

        // Editor styles (bundled with central editor script)
        $index_asset = PLUGIN_DIR . 'build/index.asset.php';
        $index       = file_exists( $index_asset ) ? include( $index_asset ) : [ 'version' => false ];
        wp_register_style(
            'groundworx-foundation-editor',
            plugins_url( 'build/index.css', __FILE__ ),
            [],
            $index['version']
        );

        // Support view modules (Interactivity API).
        $image_view_asset = PLUGIN_DIR . 'build/supports/core-image-extend/view.asset.php';
        if ( file_exists( $image_view_asset ) ) {
            $image_view = include $image_view_asset;
            wp_register_script_module(
                'groundworx-foundation/supports/core-image-extend/view',
                plugins_url( 'build/supports/core-image-extend/view.js', __FILE__ ),
                $image_view['dependencies'],
                $image_view['version']
            );
        }
    }

    /**
     * Enqueue the central editor script that registers all blocks.
     */
    function enqueue_editor_assets() {
        $asset_file = PLUGIN_DIR . 'build/index.asset.php';
        if ( ! file_exists( $asset_file ) ) return;

        $asset = include( $asset_file );

        wp_enqueue_script(
            'groundworx-foundation-editor',
            plugins_url( 'build/index.js', __FILE__ ),
            $asset['dependencies'],
            $asset['version'],
            true
        );
    }

    /**
     * Localize region group data for the editor.
     */
    function localize_region_groups() {
        $data = Region_Groups::get_editor_data();
        wp_add_inline_script(
            'groundworx-foundation-editor',
            'window.gwxRegionGroups = ' . wp_json_encode( $data ) . ';',
            'before'
        );
    }

    // Legacy enqueue methods removed — block assets now handled via
    // register_assets() + block.json handle references.

    /**
     * REMOVED: enqueue_scripts() — build/main.js was 0 bytes
     * REMOVED: enqueue_editor_scripts() — build/editor.js was 0 bytes
     * REMOVED: enqueue_styles() — build/main.css was 1 byte
     */

}

/**
 * Main instance of Groundworx Foundation.
 *
 * Returns the main instance of the plugin to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return Plugin
 */
function groundworx_foundation() {
    global $groundworx_foundation;
    if (!isset($groundworx_foundation)) {
        $groundworx_foundation = new Plugin();
        $groundworx_foundation->initialize();
    }
    return $groundworx_foundation;
}
// Deactivate groundworx-gravityforms plugin on activation (functionality now included)
register_activation_hook( __FILE__, function() {
    $plugin = 'groundworx-gravityforms/groundworx-gravityforms.php';
    if ( is_plugin_active( $plugin ) ) {
        deactivate_plugins( $plugin );
    }
});

// Initialize the plugin
groundworx_foundation();
