<?php
namespace GroundworxFoundation;

class LicenseSettings
{

    private static $instance;

    private $licensing = null;

    private $menuArgs = [];

    private $config = [];

    public function register($licensing, $config = [])
    {
        if (self::$instance) {
            return self::$instance; // Return existing instance if already set.
        }

        if (!$licensing) {
            try {
                $licensing = FluentLicensing::getInstance();
            } catch (\Exception $e) {
                return new self(); // Return empty instance if FluentLicensing is not available.
            }
        }

        $this->licensing = $licensing;

        if (!$this->config) {
            $defaultLabels = [
                'menu_title'      => 'License Settings',
                'page_title'      => 'License Settings',
                'title'           => 'License Settings',
                'description'     => 'Manage your license settings for the plugin.',
                'license_key'     => 'License Key',
                'purchase_url'    => '',
                'account_url'     => '',
                'plugin_name'     => '',
                'action_renderer' => ''
            ];

            $this->config = wp_parse_args($config, $defaultLabels);
        }

        $ajaxPrefix = 'wp_ajax_' . $this->licensing->getConfig('slug') . '_license';

        add_action($ajaxPrefix . '_activate', array($this, 'handleLicenseActivateAjax'));
        add_action($ajaxPrefix . '_deactivate', array($this, 'handleLicenseDeactivateAjax'));
        add_action($ajaxPrefix . '_status', array($this, 'handleLicenseStatusAjax'));

        if (!empty($this->config['action_renderer'])) {
            add_action('fluent_licenseing_render_' . $this->config['action_renderer'], array($this, 'renderLicensingContent'));
        }

        self::$instance = $this; // Set the instance for future use.

        return self::$instance;
    }

    public static function getInstance()
    {
        if (!self::$instance) {
            return new self();
        }

        return self::$instance; // Return the singleton instance.
    }

    public function setConfig($config = [])
    {
        $this->config = wp_parse_args($config, $this->config);
        return $this;
    }

    public function handleLicenseActivateAjax()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json([
                'message' => 'Sorry! You do not have permission to perform this action.',
            ], 422);
        }

        $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
        $licenseKey = isset($_POST['license_key']) ? sanitize_text_field($_POST['license_key']) : '';

        if (!wp_verify_nonce($nonce, 'fct_license_nonce')) {
            wp_send_json([
                'message' => 'Invalid nonce. Please try again.',
            ], 422);
        }

        if (!$licenseKey) {
            wp_send_json([
                'message' => 'Please provide a valid license key.',
            ], 422);
        }

        $currentLicense = $this->licensing->getStatus();

        if ($currentLicense['status'] === 'active' && $currentLicense['license_key'] === $licenseKey) {
            wp_send_json([
                'message' => 'This license key is already active.',
            ], 200);
        }

        $activated = $this->licensing->activate($licenseKey);

        if (is_wp_error($activated)) {
            wp_send_json([
                'message' => $activated->get_error_message(),
                'status'  => 'api_error'
            ], 422);
        }

        if ($activated['status'] !== 'valid') {
            wp_send_json([
                'message' => 'License activation failed. Please check your license key.',
                'status'  => $activated['status']
            ], 422);
        }

        return wp_send_json([
            'message' => 'License activated successfully.',
            'status'  => 'active'
        ], 200);
    }

    public function handleLicenseDeactivateAjax()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json([
                'message' => 'Sorry! You do not have permission to perform this action.',
            ], 422);
        }

        $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';

        if (!wp_verify_nonce($nonce, 'fct_license_nonce')) {
            wp_send_json([
                'message' => 'Invalid nonce. Please try again.',
            ], 422);
        }

        $deactivated = $this->licensing->deactivate();

        wp_send_json([
            'message'            => 'License deactivated successfully.',
            'remote_deactivated' => !is_wp_error($deactivated),
        ]);
    }

    public function handleLicenseStatusAjax()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json([
                'message' => 'Sorry! You do not have permission to perform this action.',
            ], 422);
        }

        $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';

        if (!wp_verify_nonce($nonce, 'fct_license_nonce')) {
            wp_send_json([
                'message' => 'Invalid nonce. Please try again.',
            ], 422);
        }

        $status = $this->licensing->getStatus(true);

        if (is_wp_error($status)) {
            wp_send_json([
                'error_notice' => $status->get_error_message(),
            ]);
        }

        $message = '';
        if (!empty($status['is_expired'])) {
            $message = '<p>Your license has expired. Please renew your license to continue receiving updates and support.</p>';
            if (!empty($status['renewal_url'])) {
                $message .= '<p><a href="' . esc_url($status['renewal_url']) . '" target="_blank" class="button button-primary fct_renew_url_btn">Renew License</a></p>';
            }
        } else if (!empty($status['error_type']) && $status['error_type'] === 'disabled') {
            $message = $status['message'] ?? '<p>Your license has been disabled. Please contact support for assistance.</p>';
        }

        unset($status['license_key']);

        wp_send_json([
            'error_notice' => $message,
            'remote_data'  => $status,
        ]);
    }

    public function addPage($args)
    {
        if (!$this->licensing) {
            return;
        }

        $this->menuArgs = wp_parse_args($args, [
            'type'        => 'submenu', // Can be: menu, options, submenu.
            'page_title'  => $this->config['page_title'] ?? '',
            'menu_title'  => $this->config['menu_title'] ?? '',
            'capability'  => 'manage_options',
            'parent_slug' => 'tools.php',
            'menu_slug'   => $this->licensing->getConfig('slug'),
            'menu_icon'   => '',
            'position'    => 999
        ]);

        add_action('admin_menu', array($this, 'createMenuPage'), 999);

        return $this;
    }

    public function createMenuPage()
    {
        switch ($this->menuArgs['type']) {
            case 'menu':
                $this->createTopeLevelMenuPage();
                break;
            case 'submenu':
                $this->createSubMenuPage();
                break;
            case 'options':
                $this->createOptionsPage();
                break;
        }
    }

    private function createTopeLevelMenuPage()
    {
        add_menu_page(
            $this->menuArgs['page_title'],
            $this->menuArgs['menu_title'],
            $this->menuArgs['capability'],
            $this->menuArgs['menu_slug'],
            array($this, 'renderLicensingContent'),
            $this->menuArgs['menu_icon'] ?? 'dashicons-admin-generic',
            $this->menuArgs['position'] ?? 100
        );
    }

    private function createOptionsPage()
    {
        if (function_exists('add_options_page')) {
            add_options_page(
                $this->menuArgs['page_title'],
                $this->menuArgs['menu_title'],
                $this->menuArgs['capability'],
                $this->menuArgs['menu_slug'],
                array($this, 'renderLicensingContent')
            );
        }
    }

    private function createSubMenuPage()
    {
        add_submenu_page(
            $this->menuArgs['parent_slug'],
            $this->menuArgs['page_title'],
            $this->menuArgs['menu_title'],
            $this->menuArgs['capability'],
            $this->menuArgs['menu_slug'],
            array($this, 'renderLicensingContent'),
            $this->menuArgs['position'] ?? 10
        );
    }

    public function enqueueAssets()
    {
        static $enqueued = false;
        if ($enqueued) {
            return;
        }
        $enqueued = true;

        $updater_url = plugin_dir_url(__FILE__);

        wp_enqueue_style(
            'fct-licensing',
            $updater_url . 'license-settings.css',
            [],
            filemtime(__DIR__ . '/license-settings.css')
        );

        wp_enqueue_script(
            'fct-licensing',
            $updater_url . 'license-settings.js',
            [],
            filemtime(__DIR__ . '/license-settings.js'),
            true
        );
    }

    public function renderLicensingContent()
    {
        if (!$this->licensing) {
            echo '<div class="fct-licensing"><p>Licensing instance is not available.</p></div>';
            return;
        }

        $this->enqueueAssets();

        $licenseStatus = $this->licensing->getStatus();
        $purchaseUrl = $this->config['purchase_url'] ?? '';
        $slug = $this->licensing->getConfig('slug');
        ?>

        <div class="fct-licensing"
             data-ajax-url="<?php echo esc_attr(admin_url('admin-ajax.php')); ?>"
             data-nonce="<?php echo esc_attr(wp_create_nonce('fct_license_nonce')); ?>"
             data-slug="<?php echo esc_attr($slug); ?>"
             data-status="<?php echo esc_attr($licenseStatus['status']); ?>">

            <div class="fct-licensing__header">
                <h1><?php echo esc_html($this->config['title']); ?></h1>
                <?php if ($this->config['account_url']): ?>
                    <a rel="noopener" target="_blank" href="<?php echo esc_url($this->config['account_url']); ?>">Account</a>
                <?php endif; ?>
            </div>

            <div class="fct-licensing__body">
                <?php if ($licenseStatus['status'] === 'valid'):
                    $isLifetime = $licenseStatus['expires'] === 'lifetime';
                    $expiresTimestamp = !$isLifetime ? strtotime($licenseStatus['expires']) : 0;
                    $daysUntilExpiry = !$isLifetime ? ceil(($expiresTimestamp - time()) / 86400) : 999;
                    $isExpiringSoon = !$isLifetime && $daysUntilExpiry <= 30 && $daysUntilExpiry > 0;
                    $isExpired = !$isLifetime && $daysUntilExpiry <= 0;
                    $snackbarClass = $isExpired ? 'fct-licensing__snackbar--expired' : ($isExpiringSoon ? 'fct-licensing__snackbar--warning' : 'fct-licensing__snackbar--success');
                    $renewUrl = $this->licensing->getRenewUrl();
                ?>
                    <div class="fct-licensing__snackbar <?php echo esc_attr($snackbarClass); ?>">
                        <span class="fct-licensing__snackbar-status">Status: <?php echo esc_html(ucfirst($licenseStatus['status'])); ?></span>
                        <span class="fct-licensing__snackbar-separator">|</span>
                        <?php if ($isLifetime): ?>
                            <span class="fct-licensing__snackbar-expires">Lifetime License</span>
                        <?php elseif ($isExpired): ?>
                            <span class="fct-licensing__snackbar-expires">Expired on <?php echo esc_html(date('M j, Y', $expiresTimestamp)); ?></span>
                            <a href="<?php echo esc_url($renewUrl); ?>" class="fct-licensing__snackbar-renew" target="_blank">Renew Now</a>
                        <?php elseif ($isExpiringSoon): ?>
                            <span class="fct-licensing__snackbar-expires">Expires in <?php echo esc_html($daysUntilExpiry); ?> day<?php echo $daysUntilExpiry === 1 ? '' : 's'; ?> (<?php echo esc_html(date('M j, Y', $expiresTimestamp)); ?>)</span>
                            <a href="<?php echo esc_url($renewUrl); ?>" class="fct-licensing__snackbar-renew" target="_blank">Renew</a>
                        <?php else: ?>
                            <span class="fct-licensing__snackbar-expires">Expires: <?php echo esc_html(date('M j, Y', $expiresTimestamp)); ?></span>
                        <?php endif; ?>
                    </div>

                    <h2>Your License is Active</h2>
                    <p>Thank you for activating your license for <?php echo esc_html($this->config['plugin_name']); ?>.</p>
                    <p><a class="fct-licensing__deactivate" href="#">Deactivate License</a></p>

                    <div class="fct-licensing__error-wrap"></div>

                <?php else: ?>
                    <h2>Please Provide the License key of <?php echo esc_html($this->config['plugin_name']); ?></h2>
                    <div class="fct-licensing__form">
                        <input type="text" name="fct_license_key"
                               value=""
                               placeholder="Your License Key"/>
                        <button class="fct-licensing__activate button button-primary">Activate License</button>
                    </div>

                    <div class="fct-licensing__error-wrap"></div>

                    <?php if ($purchaseUrl):
                        $purchaseUrlWithUtm = add_query_arg([
                            'utm_source' => 'plugin',
                            'utm_medium' => 'license-page',
                            'utm_campaign' => $slug
                        ], $purchaseUrl);
                    ?>
                        <div class="fct-licensing__purchase">
                            <p>
                                Don't have a license? <a rel="noopener" href="<?php echo esc_url($purchaseUrlWithUtm); ?>"
                                                         target="_blank">
                                    Purchase License
                                </a>
                            </p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="fct-licensing__loader">
                    <svg fill="hsl(228, 97%, 42%)" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="4" cy="12" r="3">
                            <animate id="spinner_qFRN" begin="0;spinner_OcgL.end+0.25s" attributeName="cy"
                                     calcMode="spline" dur="0.6s" values="12;6;12"
                                     keySplines=".33,.66,.66,1;.33,0,.66,.33"/>
                        </circle>
                        <circle cx="12" cy="12" r="3">
                            <animate begin="spinner_qFRN.begin+0.1s" attributeName="cy" calcMode="spline" dur="0.6s"
                                     values="12;6;12" keySplines=".33,.66,.66,1;.33,0,.66,.33"/>
                        </circle>
                        <circle cx="20" cy="12" r="3">
                            <animate id="spinner_OcgL" begin="spinner_qFRN.begin+0.2s" attributeName="cy"
                                     calcMode="spline" dur="0.6s" values="12;6;12"
                                     keySplines=".33,.66,.66,1;.33,0,.66,.33"/>
                        </circle>
                    </svg>
                </div>
            </div>
        </div>

        <div id="groundworx-foundation-settings"></div>

        <?php
    }
}
