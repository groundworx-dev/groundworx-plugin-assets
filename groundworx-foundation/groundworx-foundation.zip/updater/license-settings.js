/**
 * License Settings — handles activate / deactivate / status for each license card.
 *
 * Each `.fct-licensing` card carries its own config via data attributes:
 *   data-ajax-url, data-nonce, data-slug, data-status
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.fct-licensing' ).forEach( initCard );

		// Clean up WP admin notices on the Licenses page.
		document.querySelectorAll(
			'.update-nag, .notice, #wpbody-content > .updated, #wpbody-content > .error'
		).forEach( function ( el ) {
			el.remove();
		} );
	} );

	function initCard( card ) {
		var ajaxUrl = card.dataset.ajaxUrl;
		var nonce   = card.dataset.nonce;
		var slug    = card.dataset.slug;
		var status  = card.dataset.status;

		var body        = card.querySelector( '.fct-licensing__body' );
		var errorWrap   = card.querySelector( '.fct-licensing__error-wrap' );
		var activateBtn = card.querySelector( '.fct-licensing__activate' );
		var deactivateBtn = card.querySelector( '.fct-licensing__deactivate' );

		function setError( message, isHtml ) {
			if ( ! errorWrap ) {
				return;
			}
			if ( ! message ) {
				errorWrap.innerHTML = '';
				return;
			}
			var div = document.createElement( 'div' );
			div.className = 'fct-licensing__error';
			if ( isHtml ) {
				div.innerHTML = message;
			} else {
				div.textContent = message;
			}
			errorWrap.innerHTML = '';
			errorWrap.appendChild( div );
		}

		function sendRequest( action, data ) {
			card.classList.add( 'fct-licensing--loading' );
			setError( '' );

			data.action = slug + '_license_' + action;
			data._nonce = nonce;

			return new Promise( function ( resolve, reject ) {
				var xhr = new XMLHttpRequest();
				xhr.open( 'POST', ajaxUrl, true );
				xhr.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
				xhr.onload = function () {
					if ( xhr.status >= 200 && xhr.status < 300 ) {
						resolve( JSON.parse( xhr.responseText ) );
					} else {
						reject( JSON.parse( xhr.responseText ) );
					}
				};
				xhr.onerror = function () {
					reject( { message: 'Network error occurred while processing the request.' } );
				};
				xhr.onloadend = function () {
					card.classList.remove( 'fct-licensing--loading' );
				};
				xhr.send( new URLSearchParams( data ).toString() );
			} );
		}

		// Check remote status on load for active / expired licenses.
		if ( status !== 'unregistered' ) {
			sendRequest( 'status', {} ).then( function ( response ) {
				if ( response.error_notice ) {
					setError( response.error_notice, true );
				}
			} );
		}

		// Activate button.
		if ( activateBtn ) {
			activateBtn.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var input = card.querySelector( 'input[name="fct_license_key"]' );
				var key   = input ? input.value.trim() : '';
				if ( ! key ) {
					setError( 'Please enter a valid license key.' );
					return;
				}
				sendRequest( 'activate', { license_key: key } )
					.then( function () {
						location.reload();
					} )
					.catch( function ( error ) {
						setError( error.message || 'An error occurred while activating the license.' );
					} );
			} );
		}

		// Deactivate link.
		if ( deactivateBtn ) {
			deactivateBtn.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				sendRequest( 'deactivate', {} )
					.then( function () {
						location.reload();
					} )
					.catch( function () {
						location.reload();
					} );
			} );
		}
	}
} )();
