<?php

namespace GroundworxFoundation;

class PluginUpdater
{
    private $config = [];

    private $cache_key;

    public function __construct($config = [])
    {
        $defaults = [
            'slug'       => '',
            'basename'   => '',
            'version'    => '',
            'update_url' => '',
        ];

        $this->config = wp_parse_args($config, $defaults);
        $this->cache_key = 'gwx_update_' . $this->config['slug'];

        add_filter('pre_set_site_transient_update_plugins', array($this, 'checkUpdate'));
        add_filter('plugins_api', array($this, 'pluginInfo'), 10, 3);
    }

    /**
     * Check for plugin updates against the remote JSON.
     */
    public function checkUpdate($transient)
    {
        if (!is_object($transient)) {
            $transient = new \stdClass();
        }

        if (!empty($transient->response[$this->config['basename']])) {
            return $transient;
        }

        $remote = $this->getRemoteData();

        if (!$remote || !isset($remote->version)) {
            return $transient;
        }

        $update = (object) [
            'slug'         => $this->config['slug'],
            'plugin'       => $this->config['basename'],
            'new_version'  => $remote->version,
            'package'      => $remote->download_url ?? '',
            'url'          => $remote->homepage ?? '',
            'tested'       => $remote->tested ?? '',
            'requires'     => $remote->requires ?? '',
            'requires_php' => $remote->requires_php ?? '',
            'banners'      => isset($remote->banners) ? (array) $remote->banners : [],
            'icons'        => isset($remote->icons) ? (array) $remote->icons : [],
        ];

        if (version_compare($this->config['version'], $remote->version, '<')) {
            $transient->response[$this->config['basename']] = $update;
        } else {
            $transient->no_update[$this->config['basename']] = $update;
        }

        $transient->last_checked = time();
        $transient->checked[$this->config['basename']] = $this->config['version'];

        return $transient;
    }

    /**
     * Supply plugin info for the "View Details" modal.
     */
    public function pluginInfo($data, $action = '', $args = null)
    {
        if ('plugin_information' !== $action || !isset($args->slug) || $args->slug !== $this->config['slug']) {
            return $data;
        }

        $remote = $this->getRemoteData();

        if (!$remote) {
            return $data;
        }

        $sections = isset($remote->sections) ? (array) $remote->sections : [];

        // Fetch changelog from URL if provided.
        if (!empty($sections['changelog_url'])) {
            $changelog = $this->fetchChangelog($sections['changelog_url']);
            if ($changelog) {
                $sections['changelog'] = $changelog;
            }
            unset($sections['changelog_url']);
        }

        return (object) [
            'name'          => $remote->name ?? '',
            'slug'          => $this->config['slug'],
            'version'       => $remote->version,
            'new_version'   => $remote->version,
            'author'        => $remote->author ?? '',
            'homepage'      => $remote->homepage ?? '',
            'requires'      => $remote->requires ?? '',
            'tested'        => $remote->tested ?? '',
            'requires_php'  => $remote->requires_php ?? '',
            'download_link' => $remote->download_url ?? '',
            'sections'      => $sections,
            'banners'       => isset($remote->banners) ? (array) $remote->banners : [],
            'icons'         => isset($remote->icons) ? (array) $remote->icons : [],
        ];
    }

    /**
     * Get remote JSON data with transient caching.
     */
    private function getRemoteData()
    {
        // Force fresh fetch on update-core.php or plugin details modal.
        global $pagenow;
        $force = ('update-core.php' === $pagenow || ('plugin-install.php' === $pagenow && !empty($_GET['plugin'])));

        if (!$force) {
            $cached = get_transient($this->cache_key);
            if (false !== $cached) {
                return $cached;
            }
        }

        $response = wp_remote_get($this->config['update_url'], [
            'timeout' => 10,
        ]);

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);

        if (!$data || !isset($data->version)) {
            return false;
        }

        set_transient($this->cache_key, $data, 12 * HOUR_IN_SECONDS);

        return $data;
    }

    /**
     * Fetch changelog HTML from a remote URL.
     */
    private function fetchChangelog($url)
    {
        $cache_key = $this->cache_key . '_changelog';

        $cached = get_transient($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        $response = wp_remote_get($url, [
            'timeout' => 10,
        ]);

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return false;
        }

        $html = wp_remote_retrieve_body($response);

        if (empty($html)) {
            return false;
        }

        // Extract just the body content if it's a full HTML page.
        if (preg_match('/<body[^>]*>(.*)<\/body>/is', $html, $matches)) {
            $html = trim($matches[1]);
        }

        set_transient($cache_key, $html, 12 * HOUR_IN_SECONDS);

        return $html;
    }
}
