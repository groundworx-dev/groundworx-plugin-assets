<?php
namespace GroundworxFoundation;

defined( 'ABSPATH' ) || exit;

/**
 * Post Labels — rename the built-in "Posts" post type and optionally
 * prepend the blog page slug to single post permalinks.
 *
 * Off by default; activated from the Foundation settings panel.
 */
class PostLabels {

	/** @var array Saved settings. */
	private $settings;

	/** Option key in wp_options. */
	const OPTION_KEY = 'groundworx_foundation_post_labels';

	/** Default values — empty strings mean "keep WordPress defaults". */
	const DEFAULTS = [
		'enabled'       => false,
		'singular'      => '',
		'plural'        => '',
		'menu_name'     => '',
		'slug'          => '',
		'rewrite_front' => false,
		'sortable_categories' => false,
	];

	/**
	 * Boot.
	 */
	public function __construct() {
		$this->settings = wp_parse_args(
			get_option( self::OPTION_KEY, [] ),
			self::DEFAULTS
		);

		// Label overrides (only when enabled).
		if ( ! empty( $this->settings['enabled'] ) ) {
			add_action( 'init', [ $this, 'modify_post_type' ], 5 );
			add_filter( 'post_updated_messages', [ $this, 'updated_messages' ] );
		}

		// Front for single posts — prepend archive page path to single post permalinks.
		if ( ! empty( $this->settings['rewrite_front'] ) ) {
			add_filter( 'pre_post_link', [ $this, 'set_pre_post_link' ], 10, 3 );
			add_action( 'init', [ $this, 'add_rewrite_rules' ], 5 );
		}

		// Sortable categories — independent of label overrides.
		if ( ! empty( $this->settings['sortable_categories'] ) ) {
			add_action( 'admin_init', [ $this, 'admin_init' ] );
		}
	}

	/**
	 * Modify the built-in post type labels and menu icon.
	 */
	public function modify_post_type() {
		global $wp_post_types;

		if ( ! isset( $wp_post_types['post'] ) ) {
			return;
		}

		// If both singular and plural are empty, keep WordPress defaults entirely.
		$singular = $this->settings['singular'];
		$plural   = $this->settings['plural'];

		if ( empty( $singular ) && empty( $plural ) ) {
			return;
		}

		// Fall back to WP defaults if only one is set.
		if ( empty( $singular ) ) {
			$singular = $wp_post_types['post']->labels->singular_name;
		}
		if ( empty( $plural ) ) {
			$plural = $wp_post_types['post']->labels->name;
		}

		$menu = $this->settings['menu_name'] ?: $plural;

		$labels = $wp_post_types['post']->labels;

		$labels->name               = $plural;
		$labels->singular_name      = $singular;
		$labels->menu_name          = $menu;
		$labels->name_admin_bar     = $singular;
		// translators: %s: plural post type label
		$labels->all_items          = sprintf( __( 'All %s', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label
		$labels->archives           = sprintf( __( '%s Archives', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label
		$labels->attributes         = sprintf( __( '%s Attributes', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label (lowercase)
		$labels->insert_into_item   = sprintf( __( 'Insert into %s', 'groundworx-foundation' ), strtolower( $singular ) );
		// translators: %s: singular post type label (lowercase)
		$labels->uploaded_to_this_item = sprintf( __( 'Uploaded to this %s', 'groundworx-foundation' ), strtolower( $singular ) );
		$labels->featured_image     = __( 'Featured Image', 'groundworx-foundation' );
		$labels->set_featured_image = __( 'Set featured image', 'groundworx-foundation' );
		$labels->remove_featured_image = __( 'Remove featured image', 'groundworx-foundation' );
		$labels->use_featured_image = __( 'Use as featured image', 'groundworx-foundation' );
		// translators: %s: plural post type label
		$labels->filter_items_list  = sprintf( __( 'Filter %s list', 'groundworx-foundation' ), strtolower( $plural ) );
		// translators: %s: plural post type label
		$labels->items_list_navigation = sprintf( __( '%s list navigation', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label
		$labels->items_list         = sprintf( __( '%s list', 'groundworx-foundation' ), $plural );
		// translators: %s: singular post type label
		$labels->new_item           = sprintf( __( 'New %s', 'groundworx-foundation' ), $singular );
		$labels->add_new            = __( 'Add New', 'groundworx-foundation' );
		// translators: %s: singular post type label
		$labels->add_new_item       = sprintf( __( 'Add New %s', 'groundworx-foundation' ), $singular );
		// translators: %s: singular post type label
		$labels->edit_item          = sprintf( __( 'Edit %s', 'groundworx-foundation' ), $singular );
		// translators: %s: singular post type label
		$labels->view_item          = sprintf( __( 'View %s', 'groundworx-foundation' ), $singular );
		// translators: %s: plural post type label
		$labels->view_items         = sprintf( __( 'View %s', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label (lowercase)
		$labels->search_items       = sprintf( __( 'Search %s', 'groundworx-foundation' ), $plural );
		// translators: %s: plural post type label (lowercase)
		$labels->not_found          = sprintf( __( 'No %s found', 'groundworx-foundation' ), strtolower( $plural ) );
		// translators: %s: plural post type label (lowercase)
		$labels->not_found_in_trash = sprintf( __( 'No %s found in trash', 'groundworx-foundation' ), strtolower( $plural ) );
		// translators: %s: plural post type label
		$labels->parent_item_colon  = sprintf( __( 'Parent %s:', 'groundworx-foundation' ), $plural );
	}

	/**
	 * Add rewrite rules so single posts live under the blog page slug.
	 */
	public function add_rewrite_rules() {
		$page_for_posts = get_option( 'page_for_posts' );
		if ( ! $page_for_posts ) {
			return;
		}

		$page_path = get_page_uri( $page_for_posts );
		if ( ! $page_path ) {
			return;
		}

		add_rewrite_rule(
			"^{$page_path}/([^/]+)/?$",
			'index.php?post_type=post&name=$matches[1]',
			'top'
		);
	}

	/**
	 * Modify permalink structure when rewrite_front is on.
	 */
	public function set_pre_post_link( $permalink, $post, $leavename ) {
		if ( $post->post_type !== 'post' ) {
			return $permalink;
		}

		$page_for_posts = get_option( 'page_for_posts' );
		if ( ! $page_for_posts ) {
			return $permalink;
		}

		$page_path = get_page_uri( $page_for_posts );
		if ( ! $page_path ) {
			return $permalink;
		}

		return "/{$page_path}/{$post->post_name}/";
	}

	/**
	 * Customize post updated messages.
	 */
	public function updated_messages( $messages ) {
		global $post;

		if ( ! $post ) {
			return $messages;
		}

		$singular  = $this->settings['singular'];
		if ( empty( $singular ) ) {
			return $messages;
		}
		$permalink = get_permalink( $post );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$revision = isset( $_GET['revision'] ) ? absint( $_GET['revision'] ) : 0;

		$messages['post'] = [
			0 => '',
			// translators: 1: post type singular label, 2: permalink
			1 => sprintf( __( '%1$s updated. <a target="_blank" href="%2$s">View %1$s</a>', 'groundworx-foundation' ), $singular, esc_url( $permalink ) ),
			2 => __( 'Custom field updated.', 'groundworx-foundation' ),
			3 => __( 'Custom field deleted.', 'groundworx-foundation' ),
			// translators: %s: post type singular label
			4 => sprintf( __( '%s updated.', 'groundworx-foundation' ), $singular ),
			5 => $revision
				// translators: 1: post type singular label, 2: revision date
				? sprintf( __( '%1$s restored to revision from %2$s', 'groundworx-foundation' ), $singular, wp_post_revision_title( $revision, false ) )
				: false,
			// translators: 1: post type singular label, 2: permalink
			6 => sprintf( __( '%1$s published. <a href="%2$s">View %1$s</a>', 'groundworx-foundation' ), $singular, esc_url( $permalink ) ),
			// translators: %s: post type singular label
			7 => sprintf( __( '%s saved.', 'groundworx-foundation' ), $singular ),
			// translators: 1: post type singular label, 2: preview permalink
			8 => sprintf( __( '%1$s submitted. <a target="_blank" href="%2$s">Preview %1$s</a>', 'groundworx-foundation' ), $singular, esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
			// translators: 1: scheduled date, 2: permalink, 3: post type singular label
			9 => sprintf(
				__( '%3$s scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview %3$s</a>', 'groundworx-foundation' ),
				date_i18n( __( 'M j, Y @ G:i', 'groundworx-foundation' ), strtotime( $post->post_date ) ),
				esc_url( $permalink ),
				$singular
			),
			// translators: 1: post type singular label, 2: preview permalink
			10 => sprintf( __( '%1$s draft updated. <a target="_blank" href="%2$s">Preview %1$s</a>', 'groundworx-foundation' ), $singular, esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		];

		return $messages;
	}

	/**
	 * Admin init hooks for sortable categories.
	 */
	public function admin_init() {
		add_action( 'pre_get_posts', [ $this, 'pre_get_posts_admin' ] );
		add_filter( 'manage_edit-post_sortable_columns', [ $this, 'manage_edit_sortable_columns' ] );
	}

	/**
	 * Handle sorting by taxonomy in admin.
	 */
	public function pre_get_posts_admin( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}

		if ( $query->get( 'post_type' ) === 'post' && $query->get( 'orderby' ) === 'category' ) {
			add_filter( 'posts_clauses', [ $this, 'order_by_taxonomy_clause' ], 10, 2 );
		}
	}

	/**
	 * Modify SQL clauses for taxonomy ordering.
	 */
	public function order_by_taxonomy_clause( $clauses, $wp_query ) {
		global $wpdb;

		$clauses['join'] .= "
			LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
			LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
			LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
		";

		$taxonomy = esc_sql( $wp_query->get( 'orderby' ) );

		if ( $taxonomy ) {
			$clauses['where'] .= " AND (taxonomy = '{$taxonomy}' OR taxonomy IS NULL)";
		}

		$clauses['groupby'] = "{$wpdb->posts}.ID";
		$clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC) ";
		$clauses['orderby'] .= ( strtoupper( $wp_query->get( 'order' ) ) === 'ASC' ) ? 'ASC' : 'DESC';

		return $clauses;
	}

	/**
	 * Make categories column sortable.
	 */
	public function manage_edit_sortable_columns( $columns ) {
		$columns['categories'] = 'category';
		return $columns;
	}

	/**
	 * Get current settings for REST API.
	 */
	public static function get_settings() {
		return wp_parse_args(
			get_option( self::OPTION_KEY, [] ),
			self::DEFAULTS
		);
	}

	/**
	 * Save settings from REST API.
	 */
	public static function save_settings( $data ) {
		$sanitized = [
			'enabled'             => ! empty( $data['enabled'] ),
			'singular'            => sanitize_text_field( $data['singular'] ?? self::DEFAULTS['singular'] ),
			'plural'              => sanitize_text_field( $data['plural'] ?? self::DEFAULTS['plural'] ),
			'menu_name'           => sanitize_text_field( $data['menu_name'] ?? '' ),
			'slug'                => sanitize_title( $data['slug'] ?? '' ),
			'rewrite_front'       => ! empty( $data['rewrite_front'] ),
			'sortable_categories' => ! empty( $data['sortable_categories'] ),
		];

		update_option( self::OPTION_KEY, $sanitized );

		// Flush rewrite rules when settings change.
		flush_rewrite_rules( false );

		return $sanitized;
	}

	/**
	 * Get the page assigned as "Posts page" and available pages for the dropdown.
	 */
	public static function get_pages_data() {
		$page_for_posts = (int) get_option( 'page_for_posts', 0 );
		$page_on_front  = (int) get_option( 'page_on_front', 0 );
		$show_on_front  = get_option( 'show_on_front', 'posts' );

		$pages = get_pages( [
			'sort_column'  => 'menu_order, post_title',
			'sort_order'   => 'ASC',
			'hierarchical' => true,
		] );

		// Build a parent→depth map for indentation.
		$depth_map = [];
		foreach ( $pages as $page ) {
			if ( ! $page->post_parent ) {
				$depth_map[ $page->ID ] = 0;
			} else {
				$depth_map[ $page->ID ] = isset( $depth_map[ $page->post_parent ] )
					? $depth_map[ $page->post_parent ] + 1
					: 1;
			}
		}

		$page_list = [];
		foreach ( $pages as $page ) {
			if ( (int) $page->ID === $page_on_front ) {
				continue;
			}
			$depth  = $depth_map[ $page->ID ] ?? 0;
			$prefix = $depth > 0 ? str_repeat( "\xC2\xA0\xC2\xA0\xC2\xA0", $depth ) : '';
			$page_list[] = [
				'value' => $page->ID,
				'label' => $prefix . $page->post_title,
			];
		}

		return [
			'pageForPosts' => $page_for_posts,
			'showOnFront'  => $show_on_front,
			'pages'        => $page_list,
		];
	}

	/**
	 * Save the "Posts page" setting.
	 */
	public static function save_page_for_posts( $page_id ) {
		$page_id = absint( $page_id );
		update_option( 'page_for_posts', $page_id );

		// If a page is set, ensure show_on_front is 'page'.
		if ( $page_id > 0 ) {
			update_option( 'show_on_front', 'page' );
			// If no static front page is set, leave it — user should set that separately.
		}
	}
}
