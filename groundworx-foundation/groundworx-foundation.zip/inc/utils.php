<?php
namespace GroundworxFoundation;

defined( 'ABSPATH' ) || exit;

/**
 * Safely retrieve a GET parameter with proper sanitization.
 *
 * Handles wp_unslash and sanitization in one place to satisfy PHPCS
 * and provide consistent parameter handling across filter blocks.
 *
 * @param string $key     The parameter key to retrieve.
 * @param mixed  $default Default value if parameter doesn't exist.
 * @param string $type    Type of sanitization: 'string', 'int', or 'url'.
 * @return mixed Sanitized value or default.
 */
function gwx_core_get_param( $key, $default = '', $type = 'string' ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL params for filtering, no state change.
	if ( ! isset( $_GET[ $key ] ) || $_GET[ $key ] === '' ) {
		return $default;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$value = wp_unslash( $_GET[ $key ] );

	switch ( $type ) {
		case 'int':
			if ( is_array( $value ) ) {
				return array_map( 'intval', $value );
			}
			return intval( $value );

		case 'url':
			if ( is_array( $value ) ) {
				return array_map( 'esc_url_raw', $value );
			}
			return esc_url_raw( $value );

		case 'string':
		default:
			if ( is_array( $value ) ) {
				return array_map( 'sanitize_text_field', $value );
			}
			return sanitize_text_field( $value );
	}
}

/**
 * Safely retrieve a SERVER variable with proper sanitization.
 *
 * @param string $key     The server key to retrieve.
 * @param mixed  $default Default value if not set.
 * @return string Sanitized value or default.
 */
function gwx_core_get_server( $key, $default = '' ) {
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	if ( ! isset( $_SERVER[ $key ] ) || $_SERVER[ $key ] === '' ) {
		return $default;
	}

	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$value = wp_unslash( $_SERVER[ $key ] );

	if ( $key === 'REQUEST_URI' ) {
		return esc_url_raw( $value );
	}

	return sanitize_text_field( $value );
}

class Groundworx_Breakpoints {
	protected static $breakpoints = null;

	/**
	 * Load and cache breakpoints from JSON
	 */
	protected static function load() {
		if ( ! is_null( self::$breakpoints ) ) {
			return;
		}
	
		$path = PLUGIN_DIR . 'breakpoints.json';
	
		if ( file_exists( $path ) ) {
			$json = file_get_contents( $path );
			$data = json_decode( $json, true );
			self::$breakpoints = is_array( $data ) ? $data : [];
		} else {
			self::$breakpoints = [];
		}
	}

	/**
	 * Get all breakpoints
	 *
	 * @return array
	 */
	public static function all() {
		self::load();
		return self::$breakpoints;
	}

	/**
	 * Get raw breakpoint value by key
	 *
	 * @param string $key
	 * @return string|null
	 */
	public static function get( $key ) {
		self::load();
		return self::$breakpoints[ $key ] ?? null;
	}

	/**
	 * Get numeric value from breakpoint key or number
	 *
	 * @param string|int $key
	 * @return int|null
	 */
	public static function resolve( $key ) {
		self::load();

		// Already a number
		if ( is_numeric( $key ) ) {
			return (int) $key;
		}

		$value = self::get( $key );
		if ( $value && preg_match( '/^\d+/', $value, $matches ) ) {
			return (int) $matches[0];
		}

		return null;
	}
}
