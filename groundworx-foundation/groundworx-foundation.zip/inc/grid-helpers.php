<?php
namespace GroundworxFoundation;

defined( 'ABSPATH' ) || exit;

/**
 * Helpers for the Responsive Grid block.
 *
 * Extracts grid options, generates responsive CSS, and applies
 * Interactivity API directives.
 */

/**
 * Convert spacing preset values to CSS custom properties.
 *
 * @param string $value The spacing value (e.g., 'var:preset|spacing|tight' or '1rem').
 * @return string CSS value.
 */
function gwx_format_spacing_value( $value ) {
	if ( empty( $value ) && 0 !== $value && '0' !== $value ) {
		return '';
	}
	if ( 0 === $value || '0' === $value ) {
		return '0px';
	}
	if ( is_string( $value ) && strpos( $value, 'var:preset|' ) === 0 ) {
		$parts = explode( '|', str_replace( 'var:', '', $value ) );
		$parts = array_map( 'sanitize_title', $parts );
		return 'var(--wp--' . implode( '--', $parts ) . ')';
	}
	return $value;
}

/**
 * Extract grid options from block attributes.
 *
 * @param array $attributes Block attributes.
 * @return array Extracted options.
 */
function gwx_grid_extract_options( $attributes ) {
	$grid_options = ! empty( $attributes['gridOptions'] ) ? $attributes['gridOptions'] : array();

	$mode         = ! empty( $grid_options['mode'] ) ? $grid_options['mode'] : 'grid';
	$column_size  = ! empty( $grid_options['columnSize'] ) ? $grid_options['columnSize'] : '100%';
	$breakpoints  = ! empty( $grid_options['breakpoints'] ) ? $grid_options['breakpoints'] : array();

	$block_gap = $attributes['style']['spacing']['blockGap'] ?? null;
	$gap       = ( null !== $block_gap && '' !== $block_gap )
		? gwx_format_spacing_value( $block_gap )
		: '';

	return array(
		'grid_options' => $grid_options,
		'mode'         => $mode,
		'column_size'  => $column_size,
		'gap'          => $gap,
		'breakpoints'  => $breakpoints,
	);
}

/**
 * Generate responsive CSS for a grid block instance.
 *
 * Outputs CSS custom properties at each configured breakpoint
 * using mobile-first media queries.
 *
 * @param string $unique_class Unique class for this block instance.
 * @param string $column_size  Default column size.
 * @param string $gap          Default gap.
 * @param array  $breakpoints  Breakpoint configurations.
 * @return string Generated CSS.
 */
function gwx_generate_grid_styles( $unique_class, $column_size, $gap, $breakpoints ) {
	$rules = array();

	// Base styles (mobile-first).
	$formatted_gap     = gwx_format_spacing_value( $gap );
	$base_declarations = array(
		'--gwx-grid-size' => $column_size,
		'--gwx-grid-gap'  => $formatted_gap ? $formatted_gap : '1rem',
	);

	// Calculate column count from percentage-based size.
	if ( strpos( $column_size, '%' ) !== false ) {
		$percent = floatval( $column_size );
		if ( $percent > 0 ) {
			$base_declarations['--gwx-columns'] = (string) round( 100 / $percent );
		}
	}

	$rules['base'] = array(
		'selector'     => ".{$unique_class}",
		'declarations' => $base_declarations,
	);

	// Breakpoint styles.
	if ( ! empty( $breakpoints ) && is_array( $breakpoints ) ) {
		$sorted_breakpoints = array();
		foreach ( $breakpoints as $key => $config ) {
			$bp_value = Groundworx_Breakpoints::get( $key );
			if ( $bp_value ) {
				$sorted_breakpoints[ $key ] = array(
					'value'  => Groundworx_Breakpoints::resolve( $key ),
					'config' => $config,
					'raw'    => $bp_value,
				);
			}
		}
		uasort(
			$sorted_breakpoints,
			function ( $a, $b ) {
				return $a['value'] - $b['value'];
			}
		);

		foreach ( $sorted_breakpoints as $bp_key => $bp_data ) {
			$config       = $bp_data['config'];
			$bp_value     = $bp_data['raw'];
			$declarations = array();

			if ( isset( $config['columnSize'] ) ) {
				$size_value = $config['columnSize'];
				$declarations['--gwx-grid-size'] = $size_value;

				if ( strpos( $size_value, '%' ) !== false ) {
					$percent = floatval( $size_value );
					if ( $percent > 0 ) {
						$declarations['--gwx-columns'] = (string) round( 100 / $percent );
					}
				}
			}

			if ( ! empty( $declarations ) ) {
				$rules[ $bp_key ] = array(
					'rules_group'  => "@media (min-width: {$bp_value})",
					'selector'     => ".{$unique_class}",
					'declarations' => $declarations,
				);
			}
		}
	}

	return wp_style_engine_get_stylesheet_from_css_rules( $rules );
}

/**
 * Apply Interactivity API directives to the grid root element.
 *
 * @param \WP_HTML_Tag_Processor $processor    Tag processor on root tag.
 * @param string                 $unique_class Unique class for this instance.
 * @param array                  $grid_options Raw grid options for context.
 * @param string                 $gap          Gap value.
 * @param string                 $mode         Base mode for no-JS fallback classes.
 * @param string                 $column_size  Base column size for no-JS fallback classes.
 */
function gwx_grid_apply_directives( $processor, $unique_class, $grid_options, $gap, $mode, $column_size ) {
	$processor->add_class( $unique_class );

	// No-JS fallback classes (base mode).
	if ( 'grid' === $mode ) {
		$processor->add_class( 'gwx-grid--grid-layout' );
	} elseif ( 'flex' === $mode ) {
		$processor->add_class( 'gwx-grid--flex-layout' );
	}
	if ( strpos( $column_size, '%' ) !== false ) {
		$processor->add_class( 'has-columns' );
	}
	$equal_heights = $grid_options['equalHeights'] ?? false;
	if ( 'grid' === $mode && $equal_heights ) {
		$processor->add_class( 'gwx-grid--equal-heights' );
	}

	// Interactivity API directives.
	$processor->set_attribute( 'data-wp-interactive', 'groundworx/responsive-grid' );
	$processor->set_attribute( 'data-wp-init', 'callbacks.gridInit' );
	$processor->set_attribute( 'data-wp-on-window--resize', 'actions.updateBreakpoint' );
	$processor->set_attribute( 'data-wp-watch', 'callbacks.gridReinit' );

	// Reactive class bindings.
	$processor->set_attribute( 'data-wp-class--gwx-grid--grid-layout', 'state.isGridLayout' );
	$processor->set_attribute( 'data-wp-class--gwx-grid--flex-layout', 'state.isFlexLayout' );
	$processor->set_attribute( 'data-wp-class--gwx-grid--equal-heights', 'state.isGridEqualHeights' );
	$processor->set_attribute( 'data-wp-class--has-columns', 'state.hasColumns' );

	// Reactive CSS custom properties.
	$processor->set_attribute( 'data-wp-style----gwx-columns', 'state.columnsCss' );
	$processor->set_attribute( 'data-wp-style----gwx-flex-align', 'state.flexAlignCss' );

	// Context.
	$formatted_gap = gwx_format_spacing_value( $gap );
	$context = array(
		'gridOptions' => $grid_options,
		'gap'         => $formatted_gap ? $formatted_gap : '1rem',
	);
	$processor->set_attribute( 'data-wp-context', wp_json_encode( $context ) );
}
